import React from "react";

const Body = ({ body }) => {
  return <div>{body}</div>;
};

export default Body;

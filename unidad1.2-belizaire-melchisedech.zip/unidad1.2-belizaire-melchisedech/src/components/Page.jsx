import React from "react";

const Page = ({ children }) => {
    return <div>{children}</div>;
};

export default Page;
